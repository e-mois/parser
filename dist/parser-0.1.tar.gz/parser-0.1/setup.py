from distutils.core import setup
setup(name='parser',
      version='0.1',
      py_modules=['parser'],
      )
